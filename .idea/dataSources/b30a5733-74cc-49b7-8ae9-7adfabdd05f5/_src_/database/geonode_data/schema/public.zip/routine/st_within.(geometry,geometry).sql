CREATE FUNCTION st_within (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $2 ~ $1 AND _ST_Contains($2,$1)
$$
