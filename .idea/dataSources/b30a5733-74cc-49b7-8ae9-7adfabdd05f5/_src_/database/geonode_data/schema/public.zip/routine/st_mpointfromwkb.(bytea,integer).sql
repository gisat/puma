CREATE FUNCTION st_mpointfromwkb (bytea, integer) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1, $2)) = 'MULTIPOINT'
	THEN ST_GeomFromWKB($1, $2)
	ELSE NULL END
	
$$
