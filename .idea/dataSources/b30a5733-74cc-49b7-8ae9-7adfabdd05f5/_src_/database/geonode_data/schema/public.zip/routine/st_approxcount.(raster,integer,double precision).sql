CREATE FUNCTION st_approxcount (rast raster, nband integer, sample_percent double precision) RETURNS bigint
	LANGUAGE sql
AS $$
 SELECT _st_count($1, $2, TRUE, $3) 
$$
