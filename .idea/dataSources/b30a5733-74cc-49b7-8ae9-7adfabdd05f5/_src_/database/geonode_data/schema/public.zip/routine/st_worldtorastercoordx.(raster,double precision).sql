CREATE FUNCTION st_worldtorastercoordx (rast raster, xw double precision) RETURNS integer
	LANGUAGE sql
AS $$
 SELECT columnx FROM _st_worldtorastercoord($1, $2, NULL) 
$$
