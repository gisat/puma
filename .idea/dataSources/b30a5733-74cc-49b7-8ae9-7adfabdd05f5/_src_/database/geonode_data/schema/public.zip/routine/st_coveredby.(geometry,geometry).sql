CREATE FUNCTION st_coveredby (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 @ $2 AND _ST_CoveredBy($1,$2)
$$
