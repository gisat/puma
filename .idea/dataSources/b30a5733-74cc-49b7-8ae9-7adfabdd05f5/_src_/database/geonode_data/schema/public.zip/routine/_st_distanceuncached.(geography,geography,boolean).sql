CREATE FUNCTION _st_distanceuncached (geography, geography, boolean) RETURNS double precision
	LANGUAGE sql
AS $$
SELECT _ST_DistanceUnCached($1, $2, 0.0, $3)
$$
