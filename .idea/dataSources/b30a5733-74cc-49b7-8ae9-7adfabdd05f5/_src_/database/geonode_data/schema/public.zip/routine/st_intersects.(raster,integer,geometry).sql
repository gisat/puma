CREATE FUNCTION st_intersects (rast raster, nband integer, geom geometry) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT $1::geometry && $3 AND _st_intersects($3, $1, $2) 
$$
