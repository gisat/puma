CREATE FUNCTION raster_geometry_contain (raster, geometry) RETURNS boolean
	LANGUAGE sql
AS $$
select $1::geometry ~ $2
$$
