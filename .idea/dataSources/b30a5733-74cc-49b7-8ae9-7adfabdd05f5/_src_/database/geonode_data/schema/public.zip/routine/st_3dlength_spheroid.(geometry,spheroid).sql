CREATE FUNCTION st_3dlength_spheroid (geometry, spheroid) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT _postgis_deprecate('ST_3DLength_Spheroid', 'ST_LengthSpheroid', '2.2.0');
    SELECT ST_LengthSpheroid($1,$2);
  
$$
