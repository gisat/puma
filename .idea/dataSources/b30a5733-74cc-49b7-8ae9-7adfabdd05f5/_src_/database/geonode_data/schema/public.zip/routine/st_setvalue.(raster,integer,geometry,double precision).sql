CREATE FUNCTION st_setvalue (rast raster, nband integer, geom geometry, newvalue double precision) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT st_setvalues($1, $2, ARRAY[ROW($3, $4)]::geomval[], FALSE) 
$$
