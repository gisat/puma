CREATE FUNCTION st_intersects (rast raster, geom geometry, nband integer DEFAULT NULL::integer) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT $1::geometry && $2 AND _st_intersects($2, $1, $3) 
$$
