CREATE FUNCTION st_covers (geography, geography) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 && $2 AND _ST_Covers($1, $2)
$$
