CREATE FUNCTION postgis_scripts_installed () RETURNS text
	LANGUAGE sql
AS $$
 SELECT '2.2.1'::text || ' r' || 14555::text AS version 
$$
