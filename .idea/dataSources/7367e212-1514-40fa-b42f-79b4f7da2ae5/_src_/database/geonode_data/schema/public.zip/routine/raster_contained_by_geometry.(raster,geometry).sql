CREATE FUNCTION raster_contained_by_geometry (raster, geometry) RETURNS boolean
	LANGUAGE sql
AS $$
select $1::geometry @ $2
$$
