CREATE FUNCTION box3d (raster) RETURNS box3d
	LANGUAGE sql
AS $$
select box3d(st_convexhull($1))
$$
