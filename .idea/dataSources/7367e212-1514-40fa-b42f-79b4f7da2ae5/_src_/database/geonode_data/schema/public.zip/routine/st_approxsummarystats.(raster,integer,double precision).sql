CREATE FUNCTION st_approxsummarystats (rast raster, nband integer, sample_percent double precision) RETURNS summarystats
	LANGUAGE sql
AS $$
 SELECT _st_summarystats($1, $2, TRUE, $3) 
$$
