CREATE FUNCTION st_buffer (text, double precision) RETURNS geometry
	LANGUAGE sql
AS $$
 SELECT ST_Buffer($1::geometry, $2);  
$$
