CREATE FUNCTION st_bandisnodata (rast raster, forcechecking boolean) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT st_bandisnodata($1, 1, $2) 
$$
