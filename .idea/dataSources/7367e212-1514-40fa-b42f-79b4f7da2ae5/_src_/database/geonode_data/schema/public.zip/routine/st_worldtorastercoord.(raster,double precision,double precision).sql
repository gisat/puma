CREATE FUNCTION st_worldtorastercoord (rast raster, longitude double precision, latitude double precision, OUT columnx integer, OUT rowy integer) RETURNS record
	LANGUAGE sql
AS $$
 SELECT columnx, rowy FROM _st_worldtorastercoord($1, $2, $3) 
$$
