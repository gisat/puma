CREATE FUNCTION raster_eq (raster, raster) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT raster_hash($1) = raster_hash($2) 
$$
