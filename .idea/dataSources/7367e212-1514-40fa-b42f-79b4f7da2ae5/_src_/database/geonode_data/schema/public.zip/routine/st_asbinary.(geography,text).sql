CREATE FUNCTION st_asbinary (geography, text) RETURNS bytea
	LANGUAGE sql
AS $$
 SELECT ST_AsBinary($1::geometry, $2);  
$$
