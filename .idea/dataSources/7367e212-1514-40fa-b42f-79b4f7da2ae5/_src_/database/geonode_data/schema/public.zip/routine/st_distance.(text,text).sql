CREATE FUNCTION st_distance (text, text) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT ST_Distance($1::geometry, $2::geometry);  
$$
