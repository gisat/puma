CREATE FUNCTION st_rotation (raster) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT (ST_Geotransform($1)).theta_i 
$$
