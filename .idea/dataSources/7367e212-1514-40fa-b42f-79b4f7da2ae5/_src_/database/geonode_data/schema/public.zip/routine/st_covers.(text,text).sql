CREATE FUNCTION st_covers (text, text) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT ST_Covers($1::geometry, $2::geometry);  
$$
