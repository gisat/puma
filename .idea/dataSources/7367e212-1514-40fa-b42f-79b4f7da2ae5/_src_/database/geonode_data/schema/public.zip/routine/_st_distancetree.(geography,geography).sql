CREATE FUNCTION _st_distancetree (geography, geography) RETURNS double precision
	LANGUAGE sql
AS $$
SELECT _ST_DistanceTree($1, $2, 0.0, true)
$$
