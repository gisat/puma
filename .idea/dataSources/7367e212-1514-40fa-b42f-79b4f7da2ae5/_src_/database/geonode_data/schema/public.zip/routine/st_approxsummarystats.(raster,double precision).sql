CREATE FUNCTION st_approxsummarystats (rast raster, sample_percent double precision) RETURNS summarystats
	LANGUAGE sql
AS $$
 SELECT _st_summarystats($1, 1, TRUE, $2) 
$$
